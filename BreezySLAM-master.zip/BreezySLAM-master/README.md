BreezySLAM
==========

Simple, efficient, open-source package for Simultaneous Localization and Mapping in Python, Matlab, and C++

See http://home.wlu.edu/~levys/software/breezyslam/ for details.
